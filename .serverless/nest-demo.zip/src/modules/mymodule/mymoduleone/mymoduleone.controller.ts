import { Controller } from '@nestjs/common';

@Controller('mymoduleone')
export class MymoduleoneController {}
